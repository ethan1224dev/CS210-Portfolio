#include <iostream>
#include <fstream>
#include <string>
#include <map>
using namespace std;

// GroceryTracker class
class GroceryTracker {
private:
    map<string, int> itemFrequency; // stores item -> count

public:
    // Load data from file and count the full number of items
    void LoadDataFromFile(const string& filename) {
        ifstream inFile(filename);
        if (!inFile.is_open()) {
            cout << "Error: Could not open file " << filename << endl;
            return;
        }

        string item;
        while (inFile >> item) {
            itemFrequency[item]++; // adjust counting for each item
        }

        inFile.close();
    }

    // Write the backup file
    void WriteBackupFile(const string& filename) {
        ofstream outFile(filename);
        if (!outFile.is_open()) {
            cout << "Error: Could not create backup file " << filename << endl;
            return;
        }

        for (auto& pair : itemFrequency) {
            outFile << pair.first << " " << pair.second << endl;
        }

        outFile.close();
    }

    // Get frequency of a single item
    int GetItemFrequency(const string& item) {
        if (itemFrequency.find(item) != itemFrequency.end())
            return itemFrequency[item];
        else
            return 0;
    }

    // Print all items with counts
    void PrintAllItems() {
        cout << "All items and counts:" << endl;
        for (auto& pair : itemFrequency) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    // Print the histogram
    void PrintHistogram() {
        cout << "Histogram:" << endl;
        for (auto& pair : itemFrequency) {
            cout << pair.first << " ";
            for (int i = 0; i < pair.second; i++)
                cout << "*";
            cout << endl;
        }
    }
};

int main() {
    GroceryTracker tracker;

    // Load data and create backup
    tracker.LoadDataFromFile("grocerylist.txt");
    tracker.WriteBackupFile("frequency.dat");

    int choice = 0;
    while (choice != 4) {
        cout << "\nMenu:\n";
        cout << "1. Search for item frequency\n";
        cout << "2. Display all items and counts\n";
        cout << "3. Display histogram\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            string item;
            cout << "Enter item to search: ";
            cin >> item;
            cout << item << " appears " << tracker.GetItemFrequency(item) << " times." << endl;
        }
        else if (choice == 2) {
            tracker.PrintAllItems();
        }
        else if (choice == 3) {
            tracker.PrintHistogram();
        }
        else if (choice == 4) {
            cout << "Exiting program." << endl;
        }
        else {
            cout << "Invalid option. Try again." << endl;
        }
    }

    return 0;
}
